export const siteContent = {
  tagline: "In the gallery of time, every moment is a masterpiece",
  company: {
    name: "TIMEPIECE",
    founded: "1875"
  },
  cta: {
    primary: "SHOP NEW ARRIVALS",
    secondary: "CONFIGURE YOUR WATCH"
  }
};